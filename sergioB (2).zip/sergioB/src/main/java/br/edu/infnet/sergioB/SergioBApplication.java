package br.edu.infnet.sergioB;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SergioBApplication {

	public static void main(String[] args) {
		SpringApplication.run(SergioBApplication.class, args);
	}

}
